export interface IReport {
    printDetails();
}